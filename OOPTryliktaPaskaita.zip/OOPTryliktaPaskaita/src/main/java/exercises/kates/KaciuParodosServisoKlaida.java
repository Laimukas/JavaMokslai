package exercises.kates;

public class KaciuParodosServisoKlaida extends Exception {

    public KaciuParodosServisoKlaida(String message, Throwable cause){
        super(message, cause);
    }
}
