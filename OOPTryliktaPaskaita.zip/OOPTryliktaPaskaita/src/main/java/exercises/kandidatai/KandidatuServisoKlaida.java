package exercises.kandidatai;

public class KandidatuServisoKlaida extends Exception {

    public KandidatuServisoKlaida(String message, Throwable cause){
        super(message, cause);
    }
}
