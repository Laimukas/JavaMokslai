package exercises.sportininkai;

public class SportininkuKomanduKlaida extends Exception {

    public SportininkuKomanduKlaida(String message, Throwable cause){
        super(message, cause);
    }

}
