package exercises.ralis;

public class RalioLenktyniuKlaida extends Exception {

    public RalioLenktyniuKlaida(String message, Throwable cause){
        super(message, cause);
    }
}
